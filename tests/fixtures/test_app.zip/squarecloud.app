DISPLAY_NAME=Integration Test App
MAIN=main.py
MEMORY=512
VERSION=recommended
